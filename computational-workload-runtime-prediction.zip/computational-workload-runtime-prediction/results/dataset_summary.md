# Dataset Summary

This file is generated from the checked-in `data/workload_performance_dataset.csv`. It contains descriptive aggregates only; no values are manually entered.

## Global validation

- Observations: **384**
- Columns: **14**
- Correctness passes: **384/384**
- Unique experiment IDs: **384**
- Missing cells: **0**

## Descriptive statistics

| Metric | Mean | Median | Min | Max | Std. dev. |
|---|---:|---:|---:|---:|---:|
| `execution_time_ms` | 218.985851 | 3.095790 | 0.004078 | 7334.870096 | 873.314295 |
| `cpu_time_ms` | 195.066849 | 3.082398 | 0.007082 | 5588.493018 | 761.859133 |
| `peak_memory_kb` | 11.417513 | 8.020000 | 2.086000 | 39.188000 | 9.851803 |

## Mean runtime by algorithm

| algorithm | Runs | Mean execution time (ms) |
|---|---:|---:|
| `insertion_sort` | 128 | 640.813272 |
| `merge_sort` | 128 | 16.015539 |
| `python_timsort` | 128 | 0.128741 |

## Mean runtime by input size

| input_size | Runs | Mean execution time (ms) |
|---|---:|---:|
| `250` | 96 | 1.305382 |
| `500` | 96 | 17.677609 |
| `1000` | 96 | 158.451550 |
| `2000` | 96 | 698.508863 |

## Mean runtime by input pattern

| input_pattern | Runs | Mean execution time (ms) |
|---|---:|---:|
| `nearly_sorted` | 96 | 46.365104 |
| `random` | 96 | 317.617321 |
| `reverse_sorted` | 96 | 505.971665 |
| `sorted` | 96 | 5.989313 |

## Mean runtime by background load

| background_load | Runs | Mean execution time (ms) |
|---|---:|---:|
| `high` | 192 | 284.715369 |
| `low` | 192 | 153.256332 |

## Interpretation note

These aggregates describe the observed benchmark batch. They are not hardware-independent constants, and they should not be interpreted as causal effects without considering the experimental design and its controls.
