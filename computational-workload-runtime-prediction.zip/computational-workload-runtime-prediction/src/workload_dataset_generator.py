"""Generate an original experimental dataset for a Unit-1 ML project.

The script benchmarks three sorting algorithms under overlapping conditions
(input size, input pattern, and background CPU load) and writes one CSV row per
real execution. It uses only the Python standard library.
"""

from __future__ import annotations

import csv
import datetime as dt
import hashlib
import math
import multiprocessing as mp
import os
import platform
import random
import statistics
import time
import tracemalloc
from pathlib import Path


OUTPUT_FILE = Path("workload_performance_dataset.csv")
RANDOM_SEED = 20260810
INPUT_SIZES = [250, 500, 1000, 2000]
INPUT_PATTERNS = ["random", "sorted", "reverse_sorted", "nearly_sorted"]
ALGORITHMS = ["python_timsort", "merge_sort", "insertion_sort"]
BACKGROUND_LOADS = ["low", "high"]
REPETITIONS = 4


def insertion_sort(values: list[int]) -> list[int]:
    result = values.copy()
    for i in range(1, len(result)):
        key = result[i]
        j = i - 1
        while j >= 0 and result[j] > key:
            result[j + 1] = result[j]
            j -= 1
        result[j + 1] = key
    return result


def merge_sort(values: list[int]) -> list[int]:
    if len(values) <= 1:
        return values.copy()
    midpoint = len(values) // 2
    left = merge_sort(values[:midpoint])
    right = merge_sort(values[midpoint:])
    merged: list[int] = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


def python_timsort(values: list[int]) -> list[int]:
    return sorted(values)


SORT_FUNCTIONS = {
    "python_timsort": python_timsort,
    "merge_sort": merge_sort,
    "insertion_sort": insertion_sort,
}


def make_input(size: int, pattern: str, seed: int) -> list[int]:
    rng = random.Random(seed)
    values = [rng.randint(0, size * 10) for _ in range(size)]
    if pattern == "sorted":
        return sorted(values)
    if pattern == "reverse_sorted":
        return sorted(values, reverse=True)
    if pattern == "nearly_sorted":
        values.sort()
        swaps = max(1, size // 20)
        for _ in range(swaps):
            a, b = rng.randrange(size), rng.randrange(size)
            values[a], values[b] = values[b], values[a]
    return values


def cpu_load_worker(stop_event: mp.Event) -> None:
    value = 1.000001
    while not stop_event.is_set():
        for _ in range(20_000):
            value = math.sqrt(value + 1.000001)


def percentile(sorted_values: list[float], p: float) -> float:
    position = (len(sorted_values) - 1) * p
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return sorted_values[lower]
    fraction = position - lower
    return sorted_values[lower] * (1 - fraction) + sorted_values[upper] * fraction


def run_experiment(
    algorithm: str,
    size: int,
    pattern: str,
    load: str,
    repetition: int,
    seed: int,
) -> dict[str, object]:
    values = make_input(size, pattern, seed)
    expected = sorted(values)
    stop_event = None
    load_process = None

    if load == "high":
        stop_event = mp.Event()
        load_process = mp.Process(target=cpu_load_worker, args=(stop_event,), daemon=True)
        load_process.start()
        time.sleep(0.02)

    try:
        tracemalloc.start()
        process_start = time.process_time_ns()
        wall_start = time.perf_counter_ns()
        result = SORT_FUNCTIONS[algorithm](values)
        wall_end = time.perf_counter_ns()
        process_end = time.process_time_ns()
        _, peak_bytes = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    finally:
        if stop_event is not None:
            stop_event.set()
        if load_process is not None:
            load_process.join(timeout=1)
            if load_process.is_alive():
                load_process.terminate()
                load_process.join()

    return {
        "task_type": "integer_sorting",
        "algorithm": algorithm,
        "input_size": size,
        "input_pattern": pattern,
        "background_load": load,
        "repetition": repetition,
        "execution_time_ms": round((wall_end - wall_start) / 1_000_000, 6),
        "cpu_time_ms": round((process_end - process_start) / 1_000_000, 6),
        "peak_memory_kb": round(peak_bytes / 1024, 3),
        "correctness_passed": result == expected,
    }


def main() -> None:
    rows: list[dict[str, object]] = []
    machine_text = f"{platform.system()}|{platform.machine()}|{platform.processor()}|{os.cpu_count()}"
    system_id = "SYS-" + hashlib.sha256(machine_text.encode()).hexdigest()[:8].upper()
    collected_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()

    experiment_number = 1
    for load in BACKGROUND_LOADS:
        for size in INPUT_SIZES:
            for pattern in INPUT_PATTERNS:
                for algorithm in ALGORITHMS:
                    for repetition in range(1, REPETITIONS + 1):
                        seed = RANDOM_SEED + experiment_number
                        row = run_experiment(algorithm, size, pattern, load, repetition, seed)
                        row = {
                            "experiment_id": f"EXP-{experiment_number:04d}",
                            "collected_at_utc": collected_at,
                            "system_id": system_id,
                            **row,
                        }
                        rows.append(row)
                        experiment_number += 1

    runtimes = sorted(float(row["execution_time_ms"]) for row in rows)
    q1 = percentile(runtimes, 0.33)
    q2 = percentile(runtimes, 0.67)
    for row in rows:
        runtime = float(row["execution_time_ms"])
        row["performance_class"] = "fast" if runtime <= q1 else "moderate" if runtime <= q2 else "slow"

    fieldnames = list(rows[0].keys())
    with OUTPUT_FILE.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Created: {OUTPUT_FILE.resolve()}")
    print(f"Rows: {len(rows)} | Columns: {len(fieldnames)}")
    print(f"All correctness checks passed: {all(bool(r['correctness_passed']) for r in rows)}")
    print(f"Mean runtime: {statistics.mean(runtimes):.4f} ms")
    print(f"System ID: {system_id} (anonymised)")


if __name__ == "__main__":
    mp.freeze_support()
    main()
