# Methodology

## 1. Experimental objective

The study investigates how algorithm choice, input size, input arrangement, and controlled background CPU load affect observed sorting runtime, and whether a simple predictive model can approximate runtime within the measured range.

## 2. Workload generation

The benchmark constructs integer arrays using deterministic pseudo-random seeds and derives four input patterns: random, sorted, reverse-sorted, and nearly sorted. Three algorithms are evaluated: Python's built-in TimSort implementation through `sorted()`, a recursive Merge Sort implementation, and an Insertion Sort implementation.

## 3. Controlled factors

Each unique combination of algorithm, input size, input pattern, and background CPU-load state is repeated four times. This produces 96 unique configurations and 384 total observations.

## 4. Measurement

The generator records wall-clock runtime using `time.perf_counter_ns()`, process CPU time using `time.process_time_ns()`, and peak Python allocation using `tracemalloc`. In the high-load condition, a competing CPU-bound process is active during timing.

## 5. Correctness validation

Every returned sorted list is compared against Python's reference `sorted()` result. A benchmark observation is therefore retained together with an explicit correctness flag rather than assuming that fast execution implies correct execution.

## 6. Dataset construction

One row is written for each real benchmark execution. The resulting CSV contains measured metadata, experimental factors, timing values, memory usage, validation status, and a derived performance class.

## 7. Statistical analysis

The notebook uses descriptive statistics to characterise central tendency and dispersion, probability and conditional probability to describe categorical outcomes, expectation and variance to quantify uncertainty, and covariance/correlation to study associations among numerical variables.

## 8. Predictive modelling

Polynomial curve fitting is applied primarily to the relationship between input size and runtime. The project treats these fits as simple baseline models. In particular, extrapolation beyond the measured input range is treated cautiously because polynomial functions can produce physically impossible predictions outside the region supported by observations.

## 9. Interpretation principle

The repository distinguishes association from causation and measured values from model predictions. The experimental design supports controlled comparisons, but the single-system benchmark does not justify universal claims about all hardware or deployment environments.
