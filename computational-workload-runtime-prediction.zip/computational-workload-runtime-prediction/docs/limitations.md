# Limitations and Threats to Validity

## Scope

The benchmark currently studies one workload family—integer sorting—with three algorithms and four input sizes. The results therefore do not represent all computational workloads.

## Hardware dependence

The observations come from a single collection environment. Absolute runtime values should not be generalised to a different processor, operating system, Python build, or cloud runtime without new measurements.

## Benchmark noise

Real timing is affected by operating-system scheduling and background activity. The deliberate high-load condition is controlled at the process level but still does not turn a general-purpose computer into a perfectly isolated laboratory system.

## Memory metric

`peak_memory_kb` reflects Python allocation observed by `tracemalloc`, not total resident set size or full hardware memory traffic.

## Model limitations

The polynomial fits are intentionally simple baselines. A size-only polynomial cannot fully represent interactions among algorithm, input pattern, and background load. Extrapolation beyond the observed input range can produce nonsensical values and should not be interpreted as valid system predictions.

## Next validation step

A stronger study would repeat the protocol on multiple machines, add more observations and larger sizes, and evaluate multivariable models with explicit train/test or cross-validation procedures.
