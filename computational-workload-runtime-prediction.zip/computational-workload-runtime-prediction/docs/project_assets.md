# Project Assets

The repository intentionally keeps the original course deliverables alongside the implementation:

- `data/` — original measured dataset used for analysis
- `src/` — benchmark/data-generation source
- `notebooks/` — executed analysis notebook
- `results/figures/` — charts generated from the project analysis
- `report/` — written project report in PDF and editable DOCX forms
- `presentation/` — presentation used for project demonstration

These files are retained together so the GitHub repository acts as a complete project record rather than only a code dump.
