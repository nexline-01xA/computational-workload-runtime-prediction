# Data Dictionary

| Column | Type | Role | Description |
|---|---|---|---|
| `experiment_id` | string | identifier | Unique benchmark-run identifier |
| `collected_at_utc` | timestamp-like | metadata | UTC timestamp recorded by the generator |
| `system_id` | string | metadata | Anonymous hash/signature for the collection system |
| `task_type` | categorical | feature | Workload type; `integer_sorting` in V1 |
| `algorithm` | categorical | feature | Sorting implementation |
| `input_size` | integer | feature | Number of integers in the input |
| `input_pattern` | categorical | feature | Arrangement of the generated input |
| `background_load` | categorical | feature | Low/high competing CPU state |
| `repetition` | integer | control | Repeated-trial number (1–4) |
| `execution_time_ms` | continuous | target | Wall-clock runtime |
| `cpu_time_ms` | continuous | output | Process CPU time |
| `peak_memory_kb` | continuous | output | Peak Python allocation measured by `tracemalloc` |
| `correctness_passed` | boolean | validation | Whether the result matched the reference sorted list |
| `performance_class` | categorical | derived target | Runtime tertile label: fast/moderate/slow |
