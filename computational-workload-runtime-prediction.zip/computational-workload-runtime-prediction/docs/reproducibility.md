# Reproducibility

The repository contains the benchmark source, observed dataset, executed analysis notebook, figures, report, and presentation.

## Re-run benchmark

```bash
python src/workload_dataset_generator.py
```

The generator uses `RANDOM_SEED = 20260810` for deterministic workload construction. Because execution time is measured from a live system, regenerated timing values are expected to differ from the checked-in dataset.

## Run notebook

Open `notebooks/ML_Unit1_Workload_Analysis.ipynb` in Google Colab or Jupyter and make sure the CSV is available at the path used by the notebook.

## Reproducibility caveat

Exact absolute timings should not be treated as portable constants. CPU scheduling, processor frequency, thermal state, operating-system activity, interpreter version, and other runtime conditions can alter measurements.
