# Experimental Design

## Factorial structure

The current benchmark crosses four experimental factors:

| Factor | Levels |
|---|---|
| Algorithm | python_timsort, merge_sort, insertion_sort |
| Input size | 250, 500, 1000, 2000 |
| Input pattern | random, sorted, reverse_sorted, nearly_sorted |
| Background load | low, high |

Every combination is repeated four times.

```text
3 × 4 × 4 × 2 × 4 = 384 observations
```

## Why overlapping conditions matter

The project does not vary one factor in isolation across the whole dataset. Instead, the design creates repeated combinations so that useful controlled comparisons are available.

For example, comparing:

- Merge Sort + 1,000 + random + low load
- Merge Sort + 1,000 + random + high load

changes the background-load state while holding the other experimental descriptors constant.

Likewise, comparisons within the same size/load/pattern across algorithms expose algorithm-level differences.

This makes the dataset more useful for ML-style feature analysis than a list containing only one averaged score per algorithm.

## Replication

Four repetitions provide direct evidence of run-to-run variability. They also help prevent a single unusually fast or slow execution from being mistaken for the typical behaviour of a condition.
