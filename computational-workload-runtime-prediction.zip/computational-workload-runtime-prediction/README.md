# Machine Learning-Based Characterisation and Runtime Prediction of Computational Workloads

**Experimental ML project for workload characterisation, statistical analysis, and runtime prediction**  
B.Tech Artificial Intelligence and Machine Learning · Semester V · SRM Institute of Science and Technology

[![Python](https://img.shields.io/badge/Python-3.x-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![Jupyter](https://img.shields.io/badge/Jupyter-Notebook-F37626?logo=jupyter&logoColor=white)](https://jupyter.org/)
[![Dataset](https://img.shields.io/badge/Dataset-384%20experimental%20runs-111827)](#dataset)
[![Validation](https://img.shields.io/badge/Correctness-384%2F384-166534)](#data-quality-and-validation)
[![License](https://img.shields.io/badge/License-MIT-0F172A)](LICENSE)

> A controlled benchmarking study that turns real sorting executions into an original dataset, analyses workload effects using ML Unit 1 statistics, and explores polynomial runtime prediction.

---

## Why this repository exists

Runtime is not determined by input size alone. Algorithm choice, input arrangement, competing CPU activity, and measurement variability can interact to change observed performance.

This project treats sorting as a controlled experimental workload. Instead of importing a benchmark dataset, the included Python program **creates the dataset by executing the workloads itself**, validating every result and recording wall-clock time, CPU time, and peak Python memory.

The resulting dataset is then analysed with descriptive statistics, probability, expectation, covariance/correlation, conditional relationships, and polynomial curve fitting.

### Research questions

| ID | Question |
|---|---|
| RQ1 | How does execution time change as input size increases? |
| RQ2 | How strongly does algorithm choice affect observed execution time? |
| RQ3 | Does input arrangement materially change algorithm performance? |
| RQ4 | Does controlled background CPU load affect observed runtime? |
| RQ5 | How variable are repeated measurements of the same workload configuration? |
| RQ6 | How well can simple polynomial models approximate runtime within the observed input range? |

---

## Experimental design

The benchmark deliberately crosses four workload factors and repeats every unique configuration four times:

| Factor | Levels |
|---|---:|
| Algorithms | `python_timsort`, `merge_sort`, `insertion_sort` |
| Input sizes | `250`, `500`, `1000`, `2000` |
| Input patterns | `random`, `sorted`, `reverse_sorted`, `nearly_sorted` |
| Background CPU load | `low`, `high` |
| Repetitions | `4` |

Total observations:

```text
3 algorithms × 4 sizes × 4 patterns × 2 load states × 4 repetitions = 384 runs
```

Each row therefore represents one timed execution, not a manually entered observation.

---

## Experimental pipeline

```mermaid
flowchart LR
    A[Experimental design] --> B[Generate workload]
    B --> C[Run sorting algorithm]
    C --> D[Measure runtime + CPU + memory]
    D --> E[Validate sorted output]
    E --> F[Append observation to CSV]
    F --> G[Statistical analysis]
    G --> H[Polynomial runtime modelling]
    H --> I[Interpretation + limitations]
```

---

## Dataset

`data/workload_performance_dataset.csv` contains **384 observations across 14 columns**.

| Column | Role | Meaning |
|---|---|---|
| `experiment_id` | Identifier | Unique benchmark run ID |
| `collected_at_utc` | Metadata | Collection timestamp |
| `system_id` | Metadata | Anonymous benchmark-system signature |
| `task_type` | Feature | Workload family; currently `integer_sorting` |
| `algorithm` | Feature | Sorting method used |
| `input_size` | Feature | Number of integers sorted |
| `input_pattern` | Feature | Random / sorted / reverse-sorted / nearly-sorted input |
| `background_load` | Feature | Controlled low/high competing CPU load |
| `repetition` | Control | Replication number from 1–4 |
| `execution_time_ms` | Target | Observed wall-clock runtime in milliseconds |
| `cpu_time_ms` | Output | CPU processing time in milliseconds |
| `peak_memory_kb` | Output | Peak Python-level allocated memory during the timed operation |
| `correctness_passed` | Validation | Whether output matched the reference sorted result |
| `performance_class` | Derived target | Runtime tertile label: `fast`, `moderate`, or `slow` |

### Dataset snapshot

- **Rows:** 384
- **Columns:** 14
- **Correctness passes:** 384 / 384
- **Missing values:** 0
- **Duplicate observations:** 0
- **Unique experimental IDs:** 384
- **Unique conditions:** 96 × 4 repetitions
- **Median execution time:** 3.095790 ms
- **Maximum observed execution time:** 7334.870096 ms
- **Median peak Python memory:** 8.02 KB

Timing values are machine- and environment-dependent; exact values are therefore not expected to reproduce bit-for-bit on a different computer.

### Observed batch summary

| Aggregate | Observed value |
|---|---:|
| Mean runtime | 218.985851 ms |
| Median runtime | 3.095790 ms |
| Mean runtime — Python TimSort | 0.128741 ms |
| Mean runtime — Merge Sort | 16.015539 ms |
| Mean runtime — Insertion Sort | 640.813272 ms |
| Mean runtime — low background load | 153.256332 ms |
| Mean runtime — high background load | 284.715369 ms |

These values are descriptive aggregates from the checked-in dataset, not universal performance benchmarks.

---

## Visual evidence

The repository keeps the major analysis figures generated from the same dataset used in the notebook.

### Runtime distribution

![Runtime distribution](results/figures/01_runtime_distribution.png)

### Runtime scaling

![Runtime versus input size](results/figures/03_runtime_vs_size.png)

### Observed versus modelled runtime

![Actual versus predicted runtime](results/figures/10_actual_vs_predicted.png)

See the complete figure set in [`results/figures/`](results/figures/) and the numerical aggregates in [`results/dataset_summary.md`](results/dataset_summary.md).

---

## Data quality and validation

The analysis notebook checks the dataset before statistical analysis. The benchmark itself also validates each sorting result against Python's `sorted()` reference implementation.

The current dataset records **384 successful correctness checks out of 384 runs**. The notebook contains 31 executed code cells and no recorded execution errors.

Validation covers:

- missing values
- duplicate rows
- unique experiment IDs
- valid positive timing measurements
- correctness of every sorting result
- expected four repetitions for every `(algorithm, input_size, input_pattern, background_load)` condition

---

## Analysis

The executed notebook in `notebooks/ML_Unit1_Workload_Analysis.ipynb` covers:

1. Problem formulation and research questions
2. Dataset loading and schema inspection
3. Data-quality validation
4. Descriptive statistics
5. Probability and conditional probability
6. Expectation and variability
7. Covariance and correlation
8. Conditional/overlapping-condition analysis
9. Runtime distributions and algorithm comparisons
10. Input-size scaling analysis
11. Polynomial curve fitting
12. Actual-vs-predicted runtime visualisation
13. Limitations and scaling strategy

The project deliberately distinguishes **measured observations** from **modelled values**. Polynomial fits are treated as approximations within the observed range, not as universally valid extrapolators.

---

## Results at a glance

The dataset shows clear differences between the tested algorithms and workload conditions. For example, at `input_size = 1000`, the observed low-load measurements include sub-millisecond Python TimSort runs, millisecond-scale Merge Sort runs, and substantially larger Insertion Sort runs for random/reverse-sorted inputs. These differences are the basis for the project's workload-characterisation problem.

See the figures in [`results/figures/`](results/figures/) and the executed notebook for the complete numerical analysis.

### Included figures

| Figure | Purpose |
|---|---|
| `01_runtime_distribution.png` | Overall runtime distribution |
| `02_boxplot_by_algorithm.png` | Runtime spread by algorithm |
| `03_runtime_vs_size.png` | Runtime scaling with input size |
| `04_runtime_by_pattern.png` | Effect of input arrangement |
| `05_load_comparison.png` | Low-vs-high background CPU load |
| `06_correlation_heatmap.png` | Numerical association structure |
| `07_repetition_variability.png` | Run-to-run variability |
| `08_interaction_pattern_algorithm.png` | Algorithm × pattern interaction |
| `09_polynomial_fits.png` | Polynomial approximations |
| `10_actual_vs_predicted.png` | Modelled vs observed runtime |

---

## Reproducibility

### 1. Create an environment

```bash
python -m venv .venv
```

Windows:

```powershell
.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Regenerate the benchmark dataset

From the repository root:

```bash
python src/workload_dataset_generator.py
```

The generator uses a fixed random seed for workload construction, but **timing measurements will vary across machines and runs** because the benchmark measures real execution and includes competing CPU-load conditions.

### 4. Run the analysis notebook

Open:

```text
notebooks/ML_Unit1_Workload_Analysis.ipynb
```

It can be opened in Jupyter or Google Colab. The notebook expects `workload_performance_dataset.csv` to be available at the path configured in the notebook.

---

## Repository structure

```text
computational-workload-runtime-prediction/
├── data/
│   └── workload_performance_dataset.csv
├── src/
│   └── workload_dataset_generator.py
├── notebooks/
│   └── ML_Unit1_Workload_Analysis.ipynb
├── results/
│   └── figures/
├── report/
│   ├── ML_Workload_Project_Report.pdf
│   └── ML_Workload_Project_Report.docx
├── presentation/
│   └── ML_Workload_Project_Presentation.pptx
├── docs/
│   ├── methodology.md
│   ├── experimental_design.md
│   ├── data_dictionary.md
│   ├── reproducibility.md
│   └── limitations.md
├── .github/workflows/
│   └── validate.yml
├── CITATION.cff
├── LICENSE
├── requirements.txt
└── README.md
```

---

## Academic scope

This repository is an **academic/engineering project repository**. Its organisation follows a research-style workflow—experimental design → measurement → validation → analysis → modelling → limitations—without claiming that the project is an IEEE publication or peer-reviewed paper.

The original course work maps directly to ML Unit 1 concepts and keeps the experimental dataset, source code, analysis notebook, report, presentation, and figures together as a reproducible project record.

---

## Limitations

The current version is intentionally bounded:

- one benchmark workload family: integer sorting
- three sorting algorithms
- four input sizes up to 2,000
- four repetitions per configuration
- one benchmark-system environment / collection batch
- Python-level memory rather than hardware performance counters
- simple polynomial runtime models that do not capture every workload interaction
- absolute timing should not be interpreted as hardware-independent performance

See [`docs/limitations.md`](docs/limitations.md) for the full discussion.

---

## Future work

The benchmark can evolve into a broader workload-characterisation system by adding:

- larger input sizes and more repetitions
- additional algorithms and workload classes
- multi-machine and cloud comparisons
- CPU/GPU experiments
- richer hardware/resource telemetry
- multivariable regression and tree-based models
- uncertainty estimation
- algorithm-selection and hardware-aware scheduling recommendations

The long-term direction is to move from **runtime measurement** toward **runtime prediction and workload-aware resource selection**.

---

## Author

**Hemanth Nomula**  
B.Tech Artificial Intelligence and Machine Learning  
SRM Institute of Science and Technology

GitHub: [@nexline-01xA](https://github.com/nexline-01xA)

---

## Citation

If you reference this repository in another project, see [`CITATION.cff`](CITATION.cff).

## License

Released under the MIT License. See [`LICENSE`](LICENSE).
